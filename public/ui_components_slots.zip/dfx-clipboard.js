
import { define, html } from "hybrids";

export default define({
  tag: "dfx-clipboard",
  render: {
    shadow: { mode: "open" },
    value: (host) => html`
      <div class="wrapper">
        <slot></slot>
      </div>

      <style>
        :host {
          display: block;
        }
        .wrapper {
          padding: 0.5rem;
          border: 1px solid #ccc;
          border-radius: 4px;
        }
      </style>
    `,
  },
});
