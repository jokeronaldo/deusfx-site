
import { define, html } from "hybrids";

export default define({
  tag: "dfx-avatar",
  render: {
    shadow: { mode: "open" },
    value: (host) => html`<div class="avatar"><slot></slot></div>
    <style>
      :host {
        display: block;
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-family: sans-serif;
      }
      .avatar {
        display: block;
      }
    </style>`
  }
});
