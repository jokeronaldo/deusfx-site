
import { define, html } from "hybrids";

export default define({
  tag: "dfx-progress",
  render: {
    shadow: { mode: "open" },
    value: (host) => html`<div class="progress"><slot></slot></div>
    <style>
      :host {
        display: block;
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-family: sans-serif;
      }
      .progress {
        display: block;
      }
    </style>`
  }
});
