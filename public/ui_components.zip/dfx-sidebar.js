
import { define, html } from "hybrids";

export default define({
  tag: "dfx-sidebar",
  render: {
    shadow: { mode: "open" },
    value: (host) => html`<div class="sidebar"><slot></slot></div>
    <style>
      :host {
        display: block;
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-family: sans-serif;
      }
      .sidebar {
        display: block;
      }
    </style>`
  }
});
