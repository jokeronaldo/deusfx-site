
import { define, html } from "hybrids";

export default define({
  tag: "dfx-modal",
  render: {
    shadow: { mode: "open" },
    value: (host) => html`<div class="modal"><slot></slot></div>
    <style>
      :host {
        display: block;
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-family: sans-serif;
      }
      .modal {
        display: block;
      }
    </style>`
  }
});
