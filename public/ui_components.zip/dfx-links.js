
import { define, html } from "hybrids";

export default define({
  tag: "dfx-links",
  render: {
    shadow: { mode: "open" },
    value: (host) => html`<div class="links"><slot></slot></div>
    <style>
      :host {
        display: block;
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-family: sans-serif;
      }
      .links {
        display: block;
      }
    </style>`
  }
});
