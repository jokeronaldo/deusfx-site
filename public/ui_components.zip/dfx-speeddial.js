
import { define, html } from "hybrids";

export default define({
  tag: "dfx-speeddial",
  render: {
    shadow: { mode: "open" },
    value: (host) => html`<div class="speeddial"><slot></slot></div>
    <style>
      :host {
        display: block;
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-family: sans-serif;
      }
      .speeddial {
        display: block;
      }
    </style>`
  }
});
