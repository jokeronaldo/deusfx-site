
import { define, html } from "hybrids";

export default define({
  tag: "dfx-fileinput",
  render: {
    shadow: { mode: "open" },
    value: (host) => html`<div class="fileinput"><slot></slot></div>
    <style>
      :host {
        display: block;
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-family: sans-serif;
      }
      .fileinput {
        display: block;
      }
    </style>`
  }
});
